#ifndef INCLUDE
#define INCLUDE
#include <avr/io.h>
#include <avr/interrupt.h>
void board_init(void);
#endif 
